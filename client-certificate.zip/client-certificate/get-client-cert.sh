EnvironmentPrefix="dev"
AppName="myapp"
Namespace="mynamespace"
ClientCert="./output/tls-cert.pem"
ClientKey="./output/tls-key.pem"
CACert="./output/ca-cert.pem"
#CattedCert="./output/catted-cert.pem"
OpenSSLCert="./output/OpenSSLCert.pfx"

kubectl get secret ${AppName}-${EnvironmentPrefix}-client-certificate -n ${Namespace} -o json > .data
python3 get-certs.py
base64 -d .base64-client > ${ClientCert}
base64 -d .base64-key > ${ClientKey}
base64 -d .base64-ca > ${CACert}
#cat ${ClientCert} ${CACert} ${ClientKey} > ${CattedCert}
openssl pkcs12 -export -inkey ${ClientKey} -in ${ClientCert} -certfile ${CACert} -out ${OpenSSLCert}
#rm -f .data .base64
