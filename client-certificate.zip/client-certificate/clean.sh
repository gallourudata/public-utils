rm -f ./.base64
rm -f ./.base64-client
rm -f ./.base64-key
rm -f ./.base64-ca
rm -f ./.data
rm -f ./output/*
