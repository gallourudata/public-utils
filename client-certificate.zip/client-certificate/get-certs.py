import json

if __name__ == "__main__":
    json_file = open(".data", "r")
    json_data = json_file.read()
    parsed_data = json.loads(json_data)
    json_file.close()
    encoded_base64_client = open(".base64-client", "w")
    encoded_base64_client.writelines(parsed_data["data"]["tls.crt"])
    encoded_base64_client.close()
    encoded_base64_key = open(".base64-key", "w")
    encoded_base64_key.writelines(parsed_data["data"]["tls.key"])
    encoded_base64_key.close()
    encoded_base64_ca = open(".base64-ca", "w")
    encoded_base64_ca.writelines(parsed_data["data"]["ca.crt"])
    encoded_base64_ca.close()